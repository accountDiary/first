export const tab = {
    diary: {
      title: "다이어리입니다",
      description:
        "다이어리를 어떻게 하면 좋을까 고민",

    },
    account: {
      title: "가계부입니다.",
      description:
        " 이게 맞나....",
      
},
};
